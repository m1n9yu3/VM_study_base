﻿// 虚拟机保护_原型.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
#include<Windows.h>
using namespace std;
#define OPCODE_N  3

enum opcodes
{
    MOV = 0xf1,
    XOR = 0xf2,
    RET = 0xf4,
    STRC = 0xf5,
};
typedef struct
{
    unsigned char opcode;
    void(*handle)(void*);
}vm_opcode;
typedef struct
{
    DWORD r1;
    DWORD r2;
    DWORD r3;
    unsigned char* eip;
    DWORD* sp;
    DWORD* bp;
    unsigned char* vm_stack;
    vm_opcode op_list[OPCODE_N];
}vm_cpu;

void mov(vm_cpu* cpu)
{
    unsigned char* res = cpu->eip + 1;  //寄存器标识
    switch (*res)
    {
    case 0xa0:
    {//传送到堆栈指令
        int cout = *(cpu->eip + 6);
        unsigned char* Dest = (unsigned char*)*(DWORD*)(cpu->eip + 2);
        unsigned char* sp = (unsigned char*)(cpu->sp);
        for (int i = 0; i < cout; i++)
        {
            *sp++=*Dest++;
            //(unsigned char*)(cpu->sp)++;
        }
        (cpu->sp) =(DWORD*) sp;
        cpu->eip += 7;
        return;
    }break;
    //传送到 r1 r2   的 操作  标识符 为  a1~ a2  需要传送 sp 指针
    case 0xa1:
    {
        cpu->r1 = (DWORD)cpu->sp;
       
    }
    break;
    case 0xa2:
    {
        cpu->r2 = (DWORD)cpu->sp;
    }
    break;
    case 0xa3:   //考虑到 r3 寄存器 只是用来 传次数 
    {
        cpu->r3 = *(cpu->eip + 2);
        cpu->eip += 3;
        return;
    }
    break;
    case 0xa4:
    {
        cpu->r2 = cpu->r1;
    }
    break;

    }
    cpu->eip += 2;
    
}
void strc(vm_cpu* cpu)  //字符串比较 函数
{
    unsigned char* Dest = (unsigned char*)cpu->r1;  //字符串1 
    unsigned char* Src = (unsigned char*)cpu->r2;      //字符串2
    char  cout = *(cpu->eip + 1);   //要比较的大小
    cpu->r2 = 0;
    for (int i = 0; i < cout; i++)
    {
        cpu->r2 += *(Dest++) - *(Src++);
    }
    cpu->eip += 2;      //strc 这条指令 一共 4 个字节长度

    if (cpu->r2 == 0 )
    {
        cpu->r1 = 0;
        return;   //字符串 刚好相等 返回
    }
    else
    {
        cpu->r1 = 1;  //字符串 不相等的 操作
    }

    /*
    char* dest = vm_stack;
    char* readchar;
    readchar = new char[12];
    memcpy_s(readchar, 12, vm_stack, 12);  //用于往虚拟机的栈上读入数据
    cpu->eip += 1;			//read_ 指令占一个字节
    */
}
void Xor(vm_cpu* cpu)   //异或提供接口  堆栈里面的值  异或 另一个值
{
    int cout = 0xa;
    unsigned char key =cpu->r3;
    for (int i = 0; i < cout; i++)
    {
        *(byte*)(cpu->r1) = *(byte*)(cpu->r1) ^ key;
        cpu->r1 -= 1;
    }
    cpu->eip += 1;
    //第一个字符 不会参与 xor 加密
}

class VM
{
private:
    vm_cpu* cpu;
    int flag=0;  //定义的 默认 flag
public:
    //vm_init
    VM(unsigned char* code)
    {
        cpu = (vm_cpu*)malloc(sizeof(vm_cpu));
        memset(cpu, 0, sizeof(vm_cpu));
        cpu->r1 = 0;
        cpu->r2 = 0;
        cpu->r3 = 0;
        cpu->eip = (unsigned char*)code;   //将 eip 指向 opcode 的地址

        cpu->op_list[0].opcode = 0xf1;
        cpu->op_list[0].handle = (void(*)(void*))mov;

        cpu->op_list[1].opcode = 0xf2;
        cpu->op_list[1].handle = (void(*)(void*))Xor;

        cpu->op_list[2].opcode = 0xf5;
        cpu->op_list[2].handle = (void(*)(void*))strc;

        //初始化堆栈
        cpu->vm_stack = (unsigned char*)malloc(0x512);
        memset(cpu->vm_stack, 0, 0x512);
        cpu->sp = cpu->bp = (DWORD*)cpu->vm_stack;

        //开始执行指令
        vm_start();
    }
    int get_flag()
    {
        flag = cpu->r1;
        return flag;
    }
private:
    //执行指令
    void vm_start()
    {
        //循环执行 语句
        while ((*cpu->eip) != RET)
        {
            vm_dispatcher();
        }
    }
    void vm_dispatcher()
    {
        int i;
        for (i = 0; i < OPCODE_N; i++)
        {
            if (*cpu->eip == cpu->op_list[i].opcode)
            {
                cpu->op_list[i].handle(cpu);
                break;
            }
        }
    }

  
    //定义规则:
    /*
    1. 返回值 放在 r1 中 参数传入 使用
    */

};

void test()
{
    unsigned char vm_code[] = {
    0xf1,0xa0,0,0,0,0,0xa,0xf1,0xa3,
    0x5,0xf1,0xa1,0xf2,0xf1,0xa4,
    0xf1,0xa0,0,0,0,0,0xa,0xf1,0xa3,
    0x8,0xf1,0xa1,0xf2,0xf5,0xa,
    0xf4
    };
    char serial[255] = { 0 };
    //此段用于 隐藏字符串
    unsigned char Truecode[255] = {0x31,0x62,0x78,0x52,0x3f,0x7f,0x3e,0x52,0x3b,0x3e,0x7e,0x79,0x0};
    char s[] = { 0x25,0x73,0x0 };
    //char tishiyu[] = { "请输入flag:" };
    char flag[] = {0x66,0x6c,0x61,0x67,0x0};
    char s2[255] = {0xc7,0xeb,0xca,0xe4,0xc8,0xeb,0x66,0x6c,0x61,0x67,0x3a,0x0 };
    unsigned char s3[255] = { 0xce,0xc2,0xdc,0xb0,0xcc,0xe1,0xca,0xbe,0x3a,0x20,0x20,0xc7,0xeb,0xca,0xb9,0xd3,0xc3,0x20,0x66,0x6c,0x61,0x67,0x7b,0x25,0x73,0x7d,0x20,0xcc,0xe1,0xbd,0xbb,0x0 };
    char s4[] = { 0x25,0x73,025,0x73,0 };
    // 隐藏字符串
    //sprintf_s(s2, "%s%s",tishiyu, flag);
    while (true)
    {
        cout << s2 << endl;
        scanf_s(s, serial, 255);
        DWORD* x = (DWORD*)(vm_code + 2);
        *x = (DWORD)Truecode;
        x = (DWORD*)(vm_code + 17);
        *x = (DWORD)serial;
        VM s(vm_code);
        if (!s.get_flag())
        {
            cout << "比较成功!!" << endl;
            cout << s3 << endl;
            break;
        }
        else
        {
            cout << "比较失败" << endl;
        }
    }
    getchar();
    
    //真码:   mdcjtxh`dcjt
}

int main()
{
    test();
}


/*
    0xf1,0xa0,0,0,0,0,16,0xf1,0xa3,0x5,0xf1,0xa1,0xf2,0xf1,0xa4,
    0xf1,0xa0,0,0,0,0,16,0xf1,0xa3,0x8,0xf1,0xa1,0xf2,
    0xf5,16,0xf4
mov a0 地址  0xa  //传入 原字符串 到 堆栈
mov a3 0x5        //为 xor 准备 key
mov a1             //将 栈顶地址 传送到 r1 
xor                //xor 操作
mov a4             //将 r1  传送到 r2 中
//第一阶段结束

mov a0  地址  0xa   //传入 输入 字符串 到 堆栈
mov a3  0x8         //准备 key  8  for  xor
mov a1              //拿到 栈顶的 地址 到 r1
xor                 //xor 操作

strc 0xa            //字符串 比较  比较的结果 在 r1 中

ret                 //返回

*/



